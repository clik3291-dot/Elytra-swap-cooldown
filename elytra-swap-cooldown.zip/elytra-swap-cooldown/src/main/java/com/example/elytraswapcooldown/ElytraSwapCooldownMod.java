package com.example.elytraswapcooldown;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

/**
 * Elytra Swap Cooldown
 *
 * Проблема, яку вирішує мод: коли гравець швидко натискає комбінацію клавіш
 * для заміни елітри (chestplate <-> elytra), можливе випадкове ПОВТОРНЕ
 * натискання одразу після першого, через що предмет "свапається назад".
 *
 * Рішення: після успішного свапу мод ставить кулдаун 0.25с (5 тіків при 20 TPS)
 * на нове спрацювання цієї ж дії. Кулдаун рахується по тіках клієнта, а не по
 * системному часу — це стандартний і стабільний спосіб для Minecraft-модів.
 *
 * Це НЕ автоматизація бою і не дає переваги над іншими гравцями — мод лише
 * блокує випадкове повторне натискання, все одно потребує ручного інпуту гравця.
 */
public class ElytraSwapCooldownMod implements ClientModInitializer {

    // --- Налаштування ---

    // Скільки тіків повинно пройти між двома спрацюваннями свапу.
    // 20 тіків = 1 секунда, тож 5 тіків = 0.25 секунди.
    private static final int COOLDOWN_TICKS = 5;

    // В який слот хотбару "повертати" елітру / звідки її брати.
    // 0 = перший слот хотбару (той, що зазвичай відповідає клавіші "1").
    // Зміни це число, якщо в тебе елітра лежить в іншому слоті хотбару.
    private static final int HOTBAR_SLOT = 0;

    // Клавіша за замовчуванням, яка виконує свап. GLFW.GLFW_KEY_UNKNOWN = -1
    // означає "не прив'язано" — гравець сам призначить клавішу в меню
    // Controls -> Elytra Swap Cooldown, щоб не конфліктувати з іншими бінда.
    private static final int DEFAULT_KEY = GLFW.GLFW_KEY_UNKNOWN;

    // --- Внутрішній стан ---

    private static KeyBinding swapKey;
    private static int lastSwapTick = -COOLDOWN_TICKS; // щоб перше натискання одразу спрацювало
    private static int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elytraswapcooldown.swap",       // ідентифікатор перекладу
                InputUtil.Type.KEYSYM,                // клавіатура (не миша)
                DEFAULT_KEY,
                "category.elytraswapcooldown"         // категорія в меню Controls
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tickCounter++;

            // wasPressed() повертає true один раз за кожне натискання,
            // навіть якщо гравець тримає клавішу — це важливо, інакше
            // утримання клавіші зчитувалось би як натискання щотіку.
            while (swapKey.wasPressed()) {
                tryPerformSwap(client);
            }
        });
    }

    private void tryPerformSwap(MinecraftClient client) {
        if (client.player == null) {
            return;
        }

        int ticksSinceLastSwap = tickCounter - lastSwapTick;

        if (ticksSinceLastSwap < COOLDOWN_TICKS) {
            // Занадто рано — ігноруємо повторне натискання.
            // (можна прибрати ці два рядки, якщо не потрібне повідомлення)
            double secondsLeft = (COOLDOWN_TICKS - ticksSinceLastSwap) / 20.0;
            client.player.sendMessage(
                    Text.literal(String.format("Свап на кулдауні: %.2fс", secondsLeft))
                            .formatted(Formatting.GRAY),
                    true // true = показати в action bar, а не в чат
            );
            return;
        }

        performSwap(client);
        lastSwapTick = tickCounter;
    }

    /**
     * Власне сам свап: міняє місцями нагрудник (chestplate/elytra) гравця
     * зі стеком предметів у вказаному слоті хотбару.
     */
    private void performSwap(MinecraftClient client) {
        var player = client.player;
        if (player == null) {
            return;
        }

        // Емулюємо натискання цифрової клавіші над слотом нагрудника: викликаємо
        // той самий пакет SWAP, який Minecraft використовує для клавіш 1-9.
        // Це ОДИН виклик, який сам оновлює локальний інвентар І синхронізує
        // зміну з сервером — вручну міняти ItemStack-и не потрібно (і не можна,
        // бо це призведе до подвійного свапу).
        if (client.interactionManager != null) {
            final int CHEST_ARMOR_SCREEN_SLOT = 6; // слот нагрудника у PlayerScreenHandler

            client.interactionManager.clickSlot(
                    player.playerScreenHandler.syncId,
                    CHEST_ARMOR_SCREEN_SLOT,
                    HOTBAR_SLOT,
                    net.minecraft.screen.slot.SlotActionType.SWAP,
                    player
            );
        }
    }
}
